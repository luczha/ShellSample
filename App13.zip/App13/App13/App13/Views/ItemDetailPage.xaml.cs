﻿using System.ComponentModel;
using Xamarin.Forms;
using App13.ViewModels;

namespace App13.Views
{
    public partial class ItemDetailPage : ContentPage
    {
        public ItemDetailPage()
        {
            InitializeComponent();
            BindingContext = new ItemDetailViewModel();
        }
    }
}
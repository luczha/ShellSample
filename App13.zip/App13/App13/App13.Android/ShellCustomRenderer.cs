﻿using Android.App;

using Android.Content;

using Android.Support.Design.BottomNavigation;
using Android.Support.Design.Widget;
using Android.Views;

using Android.Widget;

using App13;

using App13.Droid;
using System;
using Xamarin.Forms;

using Xamarin.Forms.Platform.Android;

[assembly: ExportRenderer(typeof(AppShell), typeof(ShellCustomRenderer))]
namespace App13.Droid

{

    public class ShellCustomRenderer : ShellRenderer

    {

        public ShellCustomRenderer(Context context) : base(context)

        {



        }


        protected override IShellBottomNavViewAppearanceTracker CreateBottomNavViewAppearanceTracker(ShellItem shellItem)

        {

            return new MarginedTabBarAppearance();

        }


    }



    public class ToolbarAppearance : IShellToolbarAppearanceTracker

    {

        public void Dispose()

        {



        }

        public void ResetAppearance(Android.Support.V7.Widget.Toolbar toolbar, IShellToolbarTracker toolbarTracker)
        {
            throw new NotImplementedException();
        }

        public void SetAppearance(Android.Support.V7.Widget.Toolbar toolbar, IShellToolbarTracker toolbarTracker, ShellAppearance appearance)
        {
            throw new NotImplementedException();
        }
    }



   

    public class MarginedTabBarAppearance : IShellBottomNavViewAppearanceTracker

    {

        public void Dispose()

        {

        }



        public void ResetAppearance(BottomNavigationView bottomView)

        {

         
        }

      
        public void SetAppearance(BottomNavigationView bottomView, IShellAppearanceElement appearance)
        {
            bottomView.LabelVisibilityMode = LabelVisibilityMode.LabelVisibilityUnlabeled; 
        }
    }

}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using App13;
using App13.iOS;
using Foundation;
using UIKit;
using Xamarin.Forms;
using Xamarin.Forms.Platform.iOS;

[assembly: ExportRenderer(typeof(AppShell), typeof(MyShellRenderer))]
namespace App13.iOS
{
    public class MyShellRenderer : ShellRenderer
    {
        protected override IShellSectionRenderer CreateShellSectionRenderer(ShellSection shellSection)
        {
            var renderer = base.CreateShellSectionRenderer(shellSection);
            if (renderer != null)
            {

            }
            return renderer;
        }

        protected override IShellTabBarAppearanceTracker CreateTabBarAppearanceTracker()
        {
            return new CustomTabbarAppearance();
        }
    }

    public class CustomTabbarAppearance : IShellTabBarAppearanceTracker
    {
        public void Dispose()
        {

        }

        public void ResetAppearance(UITabBarController controller)
        {

        }

        public void SetAppearance(UITabBarController controller, ShellAppearance appearance)
        {
            UITabBar myTabBar = controller.TabBar;

            if (myTabBar.Items != null)
            {
                foreach (UITabBarItem item in myTabBar.Items)
                {
                    item.Title = null;
                    item.ImageInsets = new UIEdgeInsets(10, 0, 0, 0);
                }
                //The same logic if you have itemThree, itemFour....
            }

            

        }

        public void UpdateLayout(UITabBarController controller)
        {

        }
    }
}